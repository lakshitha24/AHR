'use strict';
module.exports = function(app) {
    var todoList = require('../controllers/todoListController');
    var profile = require('../controllers/profileController');

    // todoList Routes
    app.route('/tasks')
        .get(todoList.list_all_tasks)
        .post(todoList.create_a_task);

    app.route('/profile')
        .get(profile.list_all_profile)
        .post(profile.create_a_profile);


    app.route('/tasks/:taskId')
        .get(todoList.read_a_task)
        .put(todoList.update_a_task)
        .delete(todoList.delete_a_task);

    app.route('/profile/:profileId')
        .get(profile.read_a_profile)
        .put(profile.update_a_profile)
        .delete(profile.delete_a_profile);
};
