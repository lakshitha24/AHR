const serverless = require('serverless-http');
const bodyParser = require('body-parser');
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const AWS = require('aws-sdk');

AWS.config.update({
    region: 'us-west-1',
    accessKeyId: 'accessKeyId',
    secretAccessKey: 'secretAccessKey',
    endpoint: new AWS.Endpoint('http://localhost:8000'),
});

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/testDB');

app.use(bodyParser.json({ strict: false }));

var routes = require('./profile/profileRoutes'); //importing route
routes(app);

module.exports.handler = serverless(app);